# SampleStudentInformation
Sample Desktop project for learning purpose.
