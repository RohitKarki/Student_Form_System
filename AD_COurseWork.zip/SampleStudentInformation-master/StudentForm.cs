﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CourseWork
{
    public partial class StudentForm : Form
    {
        public StudentForm()
        {
            InitializeComponent();
            BindGrid("Normal_Mode");
            btnUpdate.Visible = false;
            
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            Student obj = new Student();
            if (ValidationConfirm())
            {
                string firstName = txtFirstName.Text;
                string lastName = txtLastName.Text;
                obj.Name = firstName + " " + lastName;
                obj.Address = txtAddress.Text;
                obj.Email = txtEmail.Text;
                obj.BirthDate = dpBirthDate.Value;
                obj.ContactNo = txtContactNo.Text;
                obj.Gender = cbGender.SelectedItem.ToString();
                obj.RegisterDate = dpRegister.Value;
                obj.Course = cbCourse.SelectedItem.ToString();
                obj.Status = cbStatus.SelectedItem.ToString();
                obj.Add(obj);
                BindGrid("Normal_Mode");
                MessageBox.Show("Sucessfully Register.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Clear();
            }
            else
            {

            }

        }
        public bool ValidationConfirm()
        {
            bool validate = true;
            if (string.IsNullOrEmpty(txtFirstName.Text) || string.IsNullOrEmpty(txtLastName.Text))
            {
                Message("Name");
                validate = false;
            }
            else if (string.IsNullOrEmpty(txtAddress.Text))
            {
                Message("address");
                validate = false;
            }
            else if (string.IsNullOrEmpty(txtContactNo.Text))
            {
                Message("contact");
                validate = false;
            }
            else if (string.IsNullOrEmpty(txtEmail.Text))
            {
                Message("email");
                validate = false;
            }
            else if (string.IsNullOrEmpty(cbGender.Text))
            {
                Message("gender");
                validate = false;
            }
            else if (string.IsNullOrEmpty(cbStatus.Text))
            {
                Message("status");
                validate = false;
            }
            else if (string.IsNullOrEmpty(cbCourse.Text))
            {
                Message("course");
                validate = false;
            }
            else if (ValidEmail(txtEmail.Text) == false)
            {
                MessageBox.Show("Email is not validate.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                validate = false;
            }
            return validate;
        }
        private void Message(string e)
        {
            string v = "You missed to fill the " + e + ".";
            MessageBox.Show(v, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }
        public bool ValidEmail(string source)
        {
            return new EmailAddressAttribute().IsValid(source);
        }
        private void BindGrid(string mode)
        {
            Student obj = new Student();
            List<Student> listStudents = obj.List();
            if (mode == "Name_Mode")
            {
                List<Student> ls = obj.BubbleSortByName(listStudents);
            }
            if (mode == "Date_Mode")
            {
                List<Student> ls = obj.BubbleSortByDate(listStudents);

            }
            if (mode == "Normal_Mode")
            {
                BindChart(listStudents);
                WeeklyInformationOfStudent(listStudents);
            }
            DataTable dt = Utility.ConvertToDataTable(listStudents);
            dataGridStudents.DataSource = dt;
        }
        private void Clear()
        {
            txtId.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtAddress.Text = "";
            txtEmail.Text = "";
            dpBirthDate.Value = DateTime.Today;
            txtContactNo.Text = "";
            cbGender.SelectedItem = null;
            cbStatus.SelectedItem = null;
            cbCourse.SelectedItem = null;
            dpRegister.Value = DateTime.Today;
        }

        /*private void GridRow_DbClick(object sender, DataGridViewRowEventArgs e)
        {
            int id = 0;
            string myValue = dataGridStudents[e.Row.Index, 0].Value.ToString();

            //get the clicked id 
            //read text file 
            Student obj = new Student();
            List<Student> listStudents = obj.List();
            Student s = listStudents.Where(x => x.Id == id).FirstOrDefault();
            //txtFirstName.Text = s.Name.Split(' ')[0];
            //txtLastName.Text = s.Name.Split(' ')[1];
        }*/

        private void dataGridStudents_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.ColumnIndex == 0)
            {
                //get the value of the clicked rows id column
                string value = dataGridStudents[2, e.RowIndex].Value.ToString();
                Student obj = new Student();
                int id = 0;
                if (String.IsNullOrEmpty(value))
                {
                    MessageBox.Show("Invalid Data");
                }
                else
                {
                    id = int.Parse(value);
                    Student s = obj.List().Where(x => x.Id == id).FirstOrDefault();
                    txtId.Text = s.Id.ToString();
                    txtFirstName.Text = s.Name.Split(' ')[0];
                    txtLastName.Text = s.Name.Split(' ')[1];
                    txtAddress.Text = s.Address;
                    txtEmail.Text = s.Email;
                    dpBirthDate.Value = s.BirthDate;
                    dpRegister.Value = s.RegisterDate;
                    txtContactNo.Text = s.ContactNo;
                    cbGender.SelectedItem = s.Gender;
                    cbCourse.SelectedItem = s.Course;
                    cbStatus.SelectedItem = s.Status;
                    btnSubmit.Visible = false;
                    btnUpdate.Visible = true;
                }
            }
            if (e.ColumnIndex == 1)
            {
                string value = dataGridStudents[2, e.RowIndex].Value.ToString();
                Student obj = new Student();
                int id = 0;
                if (String.IsNullOrEmpty(value))
                {
                    MessageBox.Show("Invalid Data");
                }
                else
                {
                    id = int.Parse(value);
                    obj.Delete(int.Parse(value));
                    BindGrid("Normal_Mode");
                }
                
                
            }

        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ValidationConfirm())
            {
                Student obj = new Student();
                obj.Id = int.Parse(txtId.Text);
                string firstName = txtFirstName.Text;
                string lastName = txtLastName.Text;
                obj.Name = firstName + " " + lastName;
                obj.Address = txtAddress.Text;
                obj.Email = txtEmail.Text;
                obj.BirthDate = dpBirthDate.Value;
                obj.RegisterDate = dpRegister.Value;
                obj.ContactNo = txtContactNo.Text;
                obj.Course = cbCourse.SelectedItem.ToString();
                obj.Status = cbStatus.SelectedItem.ToString();
                obj.Gender = cbGender.SelectedItem.ToString();
                obj.Edit(obj);
                MessageBox.Show("Update Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindGrid("Normal_Mode");
                Clear();
            }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void cbGender_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void BindChart(List<Student> lst)
        {
            if (lst != null)
            {

                var result = lst
                    .GroupBy(l => l.Course)
                    .Select(c1 => new
                    {
                        Course = c1.First().Course,
                        Count = c1.Count().ToString()
                    }).ToList();
                DataTable dt = Utility.ConvertToDataTable(result);
                chart1.DataSource = dt;
                chart1.Name = "Course";
                chart1.Series["Series1"].XValueMember = "Course";
                chart1.Series["Series1"].YValueMembers = "Count";
                this.chart1.Titles.Remove(this.chart1.Titles.FirstOrDefault());
                this.chart1.Titles.Add("Enrollment Chart");
                chart1.Series["Series1"].IsValueShownAsLabel = true;

            }
        }
        public void WeeklyInformationOfStudent(List<Student> lst)
        {
            if (lst != null)
            {
                var result = lst
                    .Where(t => t.Status == "Enroll")
                    .GroupBy(d => new { V = CultureInfo.CurrentCulture.Calendar.GetWeekOfYear(d.RegisterDate, CalendarWeekRule.FirstDay, DayOfWeek.Sunday), d.Course })
                    .Select(c1 => new
                    {
                        Faculty = c1.First().Course,
                        Total_Student = c1.Count().ToString(),
                        Week = "Week" + c1.Key.V.ToString(),

                    }).ToList();

                DataTable dt = Utility.ConvertToDataTable(result);
                dataGridViewWeeklyStudentReport.DataSource = dt;

            }
        }
        private void panelStudent_Paint(object sender, PaintEventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void cbStatus_TextUpdate(object sender, EventArgs e)
        {

        }

        private void btnSortingByDate_Click(object sender, EventArgs e)
        {
            BindGrid("Date_Mode");
        }
        private void btnSortingByName_Click(object sender, EventArgs e)
        {
            BindGrid("Name_Mode");
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            BindGrid("Normal_Mode");
        }
    }
}
